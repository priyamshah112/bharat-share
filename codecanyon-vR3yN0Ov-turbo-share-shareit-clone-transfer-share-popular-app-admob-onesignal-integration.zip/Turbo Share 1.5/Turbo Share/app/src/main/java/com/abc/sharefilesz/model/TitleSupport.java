package com.abc.sharefilesz.model;

import android.content.Context;

public interface TitleSupport
{
    CharSequence getTitle(Context context);
}
