package com.abc.sharefilesz.util;

public interface DetachListener
{
    void onPrepareDetach();
}
