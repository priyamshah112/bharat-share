package com.abc.sharefilesz.util;

import androidx.annotation.DrawableRes;

public interface IconSupport
{
    @DrawableRes
    int getIconRes();
}
