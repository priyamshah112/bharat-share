package com.abc.sharefilesz.util;

public class NotReadyException extends Exception
{
    public NotReadyException(String msg)
    {
        super(msg);
    }
}
