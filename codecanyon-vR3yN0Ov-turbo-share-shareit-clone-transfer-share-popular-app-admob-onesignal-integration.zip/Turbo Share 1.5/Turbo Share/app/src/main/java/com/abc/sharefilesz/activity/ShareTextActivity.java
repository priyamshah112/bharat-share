package com.abc.sharefilesz.activity;

public class ShareTextActivity extends Activity
{
}
