package com.abc.sharefilesz.util;

import com.genonbeta.android.framework.widget.PowerfulActionMode;

public interface PowerfulActionModeSupport
{
    PowerfulActionMode getPowerfulActionMode();
}
