package com.abc.sharefilesz.activity;

public class SearchActivity extends Activity
{
}
